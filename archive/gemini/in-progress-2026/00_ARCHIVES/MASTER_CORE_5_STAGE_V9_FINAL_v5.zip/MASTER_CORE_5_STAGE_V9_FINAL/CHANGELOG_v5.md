# CHANGELOG_v5 — MASTER_CORE_5_STAGE_V9_FINAL_v5

## Phạm vi

Đã cập nhật bộ v4, giữ nguyên 5 CORE TXT và 5 KB PDF; không đổi tên 10 file nội dung. Các CORE vẫn giữ nguyên các section `[0]`–`[19]`; chỉ bổ sung runtime override và ba section `[20]`–`[22]` theo yêu cầu.

## File đã sửa

**CORE (5/5):**
- `STRANGER_CORE_V9.txt`
- `ADDED_ONLY_CORE_V9.txt`
- `EARLY_TALKING_CORE_V9.txt`
- `MET_IN_PERSON_CORE_V9.txt`
- `DATING_CORE_V9.txt`

**KB (5/5):**
- `STRANGER_KB_V9.pdf`
- `ADDED_ONLY_KB_V9.pdf`
- `EARLY_TALKING_KB_V9.pdf`
- `MET_IN_PERSON_KB_V9.pdf`
- `DATING_KB_V9.pdf`

## Xác nhận các thay đổi

- Đã thêm `TACITURN_BADBOY` vào `[11.5] TONE_ENGINE` của cả 5 CORE và vào `[E] TONE ENGINE NOTES` + `[K] STYLE PROFILES` của cả 5 KB.
- Đã thêm `TACITURN_DEFAULT_MODE` vào `[8] CHARACTER BUDGET` và liên kết kích hoạt từ `[9] SHORT MODE` trong cả 5 CORE; HARD MAX 80 cho các mode khác vẫn được giữ nguyên.
- Đã thêm `[20] SUBTEXT_READING`, `[21] LOGIC_ENGINE`, `[22] NON_BOT_FEEL` vào cuối cả 5 CORE, sau `[19] FEEDBACK_LOOP`.
- Đã thêm các cặp BAD/GOOD 39–44 vào cuối `[I]` của cả 5 KB; mỗi KB hiện có đúng 44 cặp.
- Đã thêm `NEW_CHECK_8: SUBTEXT_ADDRESSED` và `NEW_CHECK_9: LOGIC_CONSISTENT` vào `[18] HARD_QC` của cả 5 CORE.
- Đã cập nhật header và mục lục KB lên `11 PROFILES` và `44 BAD vs GOOD` / `44 BAD/GOOD PAIRS`; Research notes đổi `ten internal tone labels` thành `eleven internal tone labels`.
- Các trang KB được dàn lại trong cùng cấu trúc 5 trang để đảm bảo thứ tự mục `[I]` → `[J]` → `[K]` → `[L]` → `[M]` → `[N]` → `[O]`, và nội dung mới không bị chồng lấn.

## Kiểm tra PDF

- Cả 5 PDF đã được lưu lại, render và kiểm tra bằng PDFium.
- Kiểm tra cấu trúc: 5 trang/PDF, 44 cặp BAD/GOOD duy nhất từ 01 đến 44, 12 recovery protocols, 11 style profiles.
- Trang 1 được kiểm tra riêng; không thấy chuỗi ký tự rác `1 1 1 1...` hoặc `¡¢£¤¥...` trong text extraction hay bản render.
- Lỗi PDF còn lại: **không phát hiện** trong kiểm tra mở file, trích xuất text và render. Bố cục trang 3–5 đã được reflow để chứa nội dung bổ sung; nội dung và thứ tự section được giữ lại.

## Ghi chú định dạng

- Giữ ngôn ngữ trộn Việt–Anh và cấu trúc `PATTERN / FUNCTION / ANTI_PATTERN`.
- Không xóa section an toàn hiện hữu; `TACITURN_BADBOY` có guardrail rõ ràng để không biến kiệm lời thành silent treatment.
